"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
const node_fetch_1 = __importDefault(require("node-fetch"));
function paramsToObject(entries) {
    const result = {};
    for (const [key, value] of entries) {
        // each 'entry' is a [key, value] tupple
        result[key] = value;
    }
    return result;
}
exports.main = async function (event) {
    const { request } = event.Records[0].cf;
    const queryParams = new URLSearchParams(request.querystring);
    const queryParamsObj = paramsToObject(queryParams.entries());
    const alias = queryParamsObj.alias;
    const response = {
        status: '200',
        statusDescription: 'OK',
    };
    let oldBody = await (await node_fetch_1.default('https://zk.money/index.html')).text();
    if (alias) {
        oldBody = oldBody.replace('$IMAGE_CONTENT', `https://res.cloudinary.com/df4pltas6/image/upload/c_scale,w_1459/g_south_west,l_e_colorize,co_white,l_text:lato_60:@${alias},x_165,y_115/v1615319371/Group_206_1_orgtk1.png`);
        oldBody = oldBody.replace('$TEXT_CONTENT', `Checkout zk.money by @aztecnetwork. You can now send me crypto privately @${alias} 🕵️.`);
        return {
            ...response,
            headers: {
                'cache-control': [
                    {
                        key: 'Cache-Control',
                        value: 'max-age=3600',
                    },
                ],
                'content-type': [
                    {
                        key: 'Content-Type',
                        value: 'text/html',
                    },
                ],
            },
            body: oldBody,
        };
    }
    else {
        oldBody = oldBody.replace('$IMAGE_CONTENT', `https://res.cloudinary.com/df4pltas6/image/upload/c_scale,w_1459/g_south_west,l_e_colorize,co_white,l_text:lato_60:,x_165,y_115/v1615319371/Group_206_1_orgtk1.png`);
        oldBody = oldBody.replace('$TEXT_CONTENT', `Checkout zk.money by @aztecnetwork. You can now send crypto privately 🕵️.`);
        return {
            ...response,
            headers: {
                'cache-control': [
                    {
                        key: 'Cache-Control',
                        value: 'max-age=3600',
                    },
                ],
                'content-type': [
                    {
                        key: 'Content-Type',
                        value: 'text/html',
                    },
                ],
            },
            body: oldBody,
        };
    }
};
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiaW5kZXguanMiLCJzb3VyY2VSb290IjoiIiwic291cmNlcyI6WyIuLi9zcmMvaW5kZXgudHMiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6Ijs7Ozs7QUFBQSw0REFBK0I7QUFFL0IsU0FBUyxjQUFjLENBQUMsT0FBMkM7SUFDakUsTUFBTSxNQUFNLEdBQThCLEVBQUUsQ0FBQztJQUM3QyxLQUFLLE1BQU0sQ0FBQyxHQUFHLEVBQUUsS0FBSyxDQUFDLElBQUksT0FBTyxFQUFFO1FBQ2xDLHdDQUF3QztRQUN4QyxNQUFNLENBQUMsR0FBRyxDQUFDLEdBQUcsS0FBSyxDQUFDO0tBQ3JCO0lBQ0QsT0FBTyxNQUFNLENBQUM7QUFDaEIsQ0FBQztBQU1ELE9BQU8sQ0FBQyxJQUFJLEdBQUcsS0FBSyxXQUFXLEtBQVU7SUFDdkMsTUFBTSxFQUFFLE9BQU8sRUFBRSxHQUFHLEtBQUssQ0FBQyxPQUFPLENBQUMsQ0FBQyxDQUFDLENBQUMsRUFBRSxDQUFDO0lBQ3hDLE1BQU0sV0FBVyxHQUFHLElBQUksZUFBZSxDQUFDLE9BQU8sQ0FBQyxXQUFXLENBQW9CLENBQUM7SUFDaEYsTUFBTSxjQUFjLEdBQUcsY0FBYyxDQUFDLFdBQVcsQ0FBQyxPQUFPLEVBQUUsQ0FBYSxDQUFDO0lBQ3pFLE1BQU0sS0FBSyxHQUFHLGNBQWMsQ0FBQyxLQUFLLENBQUM7SUFFbkMsTUFBTSxRQUFRLEdBQUc7UUFDZixNQUFNLEVBQUUsS0FBSztRQUNiLGlCQUFpQixFQUFFLElBQUk7S0FDeEIsQ0FBQztJQUNGLElBQUksT0FBTyxHQUFHLE1BQU0sQ0FBQyxNQUFNLG9CQUFLLENBQUMsNkJBQTZCLENBQUMsQ0FBQyxDQUFDLElBQUksRUFBRSxDQUFDO0lBRXhFLElBQUksS0FBSyxFQUFFO1FBQ1QsT0FBTyxHQUFHLE9BQU8sQ0FBQyxPQUFPLENBQ3ZCLGdCQUFnQixFQUNoQix1SEFBdUgsS0FBSyxpREFBaUQsQ0FDOUssQ0FBQztRQUNGLE9BQU8sR0FBRyxPQUFPLENBQUMsT0FBTyxDQUN2QixlQUFlLEVBQ2YsNkVBQTZFLEtBQUssT0FBTyxDQUMxRixDQUFDO1FBQ0YsT0FBTztZQUNMLEdBQUcsUUFBUTtZQUNYLE9BQU8sRUFBRTtnQkFDUCxlQUFlLEVBQUU7b0JBQ2Y7d0JBQ0UsR0FBRyxFQUFFLGVBQWU7d0JBQ3BCLEtBQUssRUFBRSxjQUFjO3FCQUN0QjtpQkFDRjtnQkFDRCxjQUFjLEVBQUU7b0JBQ2Q7d0JBQ0UsR0FBRyxFQUFFLGNBQWM7d0JBQ25CLEtBQUssRUFBRSxXQUFXO3FCQUNuQjtpQkFDRjthQUNGO1lBQ0QsSUFBSSxFQUFFLE9BQU87U0FDZCxDQUFDO0tBQ0g7U0FBTTtRQUNMLE9BQU8sR0FBRyxPQUFPLENBQUMsT0FBTyxDQUN2QixnQkFBZ0IsRUFDaEIsb0tBQW9LLENBQ3JLLENBQUM7UUFDRixPQUFPLEdBQUcsT0FBTyxDQUFDLE9BQU8sQ0FDdkIsZUFBZSxFQUNmLDRFQUE0RSxDQUM3RSxDQUFDO1FBQ0YsT0FBTztZQUNMLEdBQUcsUUFBUTtZQUNYLE9BQU8sRUFBRTtnQkFDUCxlQUFlLEVBQUU7b0JBQ2Y7d0JBQ0UsR0FBRyxFQUFFLGVBQWU7d0JBQ3BCLEtBQUssRUFBRSxjQUFjO3FCQUN0QjtpQkFDRjtnQkFDRCxjQUFjLEVBQUU7b0JBQ2Q7d0JBQ0UsR0FBRyxFQUFFLGNBQWM7d0JBQ25CLEtBQUssRUFBRSxXQUFXO3FCQUNuQjtpQkFDRjthQUNGO1lBQ0QsSUFBSSxFQUFFLE9BQU87U0FDZCxDQUFDO0tBQ0g7QUFDSCxDQUFDLENBQUMifQ==