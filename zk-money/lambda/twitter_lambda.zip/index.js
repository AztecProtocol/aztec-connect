"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
const node_fetch_1 = __importDefault(require("node-fetch"));
function paramsToObject(entries) {
    const result = {};
    for (const [key, value] of entries) {
        // each 'entry' is a [key, value] tupple
        result[key] = value;
    }
    return result;
}
exports.main = async function (event) {
    const { request } = event.Records[0].cf;
    const queryParams = new URLSearchParams(request.querystring);
    const queryParamsObj = paramsToObject(queryParams.entries());
    const alias = queryParamsObj.alias;
    const response = {
        status: '200',
        statusDescription: 'OK',
    };
    let oldBody = await (await (0, node_fetch_1.default)('https://zk.money/index.html')).text();
    if (alias) {
        oldBody = oldBody.replace('$IMAGE_CONTENT', `https://res.cloudinary.com/df4pltas6/image/upload/c_scale,w_1459/g_south_east,l_e_colorize,co_white,l_text:lato_80:@${alias},x_90,y_200/v1615319371/Share_image_1_ohjf3m.png`);
        oldBody = oldBody.replace('$TEXT_CONTENT', `Checkout zk.money by @aztecnetwork. Private DeFi is here. Send me crypto privately @${alias} 🕵️.`);
        return {
            ...response,
            body: oldBody,
        };
    }
    else {
        oldBody = oldBody.replace('$IMAGE_CONTENT', `https://res.cloudinary.com/df4pltas6/image/upload/c_scale,w_1459/v1615319371/Share_image_1_ohjf3m.png`);
        oldBody = oldBody.replace('$TEXT_CONTENT', `Checkout zk.money by @aztecnetwork. Private DeFi is here. 🕵️.`);
        return {
            ...response,
            body: oldBody,
        };
    }
};
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiaW5kZXguanMiLCJzb3VyY2VSb290IjoiIiwic291cmNlcyI6WyIuLi9zcmMvaW5kZXgudHMiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6Ijs7Ozs7QUFBQSw0REFBK0I7QUFFL0IsU0FBUyxjQUFjLENBQUMsT0FBMkM7SUFDakUsTUFBTSxNQUFNLEdBQThCLEVBQUUsQ0FBQztJQUM3QyxLQUFLLE1BQU0sQ0FBQyxHQUFHLEVBQUUsS0FBSyxDQUFDLElBQUksT0FBTyxFQUFFO1FBQ2xDLHdDQUF3QztRQUN4QyxNQUFNLENBQUMsR0FBRyxDQUFDLEdBQUcsS0FBSyxDQUFDO0tBQ3JCO0lBQ0QsT0FBTyxNQUFNLENBQUM7QUFDaEIsQ0FBQztBQU1ELE9BQU8sQ0FBQyxJQUFJLEdBQUcsS0FBSyxXQUFXLEtBQVU7SUFDdkMsTUFBTSxFQUFFLE9BQU8sRUFBRSxHQUFHLEtBQUssQ0FBQyxPQUFPLENBQUMsQ0FBQyxDQUFDLENBQUMsRUFBRSxDQUFDO0lBQ3hDLE1BQU0sV0FBVyxHQUFHLElBQUksZUFBZSxDQUFDLE9BQU8sQ0FBQyxXQUFXLENBQW9CLENBQUM7SUFDaEYsTUFBTSxjQUFjLEdBQUcsY0FBYyxDQUFDLFdBQVcsQ0FBQyxPQUFPLEVBQUUsQ0FBYSxDQUFDO0lBQ3pFLE1BQU0sS0FBSyxHQUFHLGNBQWMsQ0FBQyxLQUFLLENBQUM7SUFFbkMsTUFBTSxRQUFRLEdBQUc7UUFDZixNQUFNLEVBQUUsS0FBSztRQUNiLGlCQUFpQixFQUFFLElBQUk7S0FDeEIsQ0FBQztJQUNGLElBQUksT0FBTyxHQUFHLE1BQU0sQ0FBQyxNQUFNLElBQUEsb0JBQUssRUFBQyw2QkFBNkIsQ0FBQyxDQUFDLENBQUMsSUFBSSxFQUFFLENBQUM7SUFFeEUsSUFBSSxLQUFLLEVBQUU7UUFDVCxPQUFPLEdBQUcsT0FBTyxDQUFDLE9BQU8sQ0FDdkIsZ0JBQWdCLEVBQ2hCLHVIQUF1SCxLQUFLLGtEQUFrRCxDQUMvSyxDQUFDO1FBQ0YsT0FBTyxHQUFHLE9BQU8sQ0FBQyxPQUFPLENBQ3ZCLGVBQWUsRUFDZix1RkFBdUYsS0FBSyxPQUFPLENBQ3BHLENBQUM7UUFDRixPQUFPO1lBQ0wsR0FBRyxRQUFRO1lBQ1gsSUFBSSxFQUFFLE9BQU87U0FDZCxDQUFDO0tBQ0g7U0FBTTtRQUNMLE9BQU8sR0FBRyxPQUFPLENBQUMsT0FBTyxDQUN2QixnQkFBZ0IsRUFDaEIsdUdBQXVHLENBQ3hHLENBQUM7UUFDRixPQUFPLEdBQUcsT0FBTyxDQUFDLE9BQU8sQ0FDdkIsZUFBZSxFQUNmLGdFQUFnRSxDQUNqRSxDQUFDO1FBQ0YsT0FBTztZQUNMLEdBQUcsUUFBUTtZQUNYLElBQUksRUFBRSxPQUFPO1NBQ2QsQ0FBQztLQUNIO0FBQ0gsQ0FBQyxDQUFDIn0=