export declare const main: (event: any, ctx: any, callback: any) => Promise<void>;
//# sourceMappingURL=index.d.ts.map