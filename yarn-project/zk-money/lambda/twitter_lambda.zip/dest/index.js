"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.main = void 0;
function paramsToObject(entries) {
    const result = {};
    for (const [key, value] of entries) {
        // each 'entry' is a [key, value] tupple
        result[key] = value;
    }
    return result;
}
const main = async function (event, ctx, callback) {
    const { request, response } = event.Records[0].cf;
    const queryParams = new URLSearchParams(request.querystring);
    const queryParamsObj = paramsToObject(queryParams.entries());
    const alias = queryParamsObj.alias;
    const uri = request.uri;
    const lambdaPaths = ['/', '/index.html'];
    response.status = '200';
    response.statusDescription = 'OK';
    const hostName = request.headers.host[0].value;
    let oldBody = await (await fetch(`http://${hostName}`)).text();
    if (alias && lambdaPaths.indexOf(uri) > -1) {
        response.body = oldBody.replace('$IMAGE_CONTENT', `https://res.cloudinary.com/df4pltas6/image/upload/c_scale,w_1459/g_south_east,l_e_colorize,co_white,l_text:lato_80:@${alias},x_170,y_270/v1615319371/Share_image_3_uo7zrx.png`);
        response.body = response.body.replace('$TEXT_CONTENT', `Checkout zk.money by @aztecnetwork. Private DeFi is here. Send me crypto privately @${alias} 🕵️.`);
        response.headers['content-type'] = [
            {
                key: 'Content-Type',
                value: 'text/html; charset=utf-8',
            },
        ];
    }
    else if (lambdaPaths.indexOf(uri) > -1) {
        response.body = oldBody.replace('$IMAGE_CONTENT', `https://res.cloudinary.com/df4pltas6/image/upload/c_scale,w_1459/v1615319371/Share_image_3_uo7zrx.png`);
        response.body = response.body.replace('$TEXT_CONTENT', `Checkout zk.money by @aztecnetwork. Private DeFi is here. 🕵️.`);
        response.headers['content-type'] = [
            {
                key: 'Content-Type',
                value: 'text/html; charset=utf-8',
            },
        ];
    }
    callback(null, response);
};
exports.main = main;
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiaW5kZXguanMiLCJzb3VyY2VSb290IjoiIiwic291cmNlcyI6WyIuLi9zcmMvaW5kZXgudHMiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6Ijs7O0FBQUEsU0FBUyxjQUFjLENBQUMsT0FBMkM7SUFDakUsTUFBTSxNQUFNLEdBQThCLEVBQUUsQ0FBQztJQUM3QyxLQUFLLE1BQU0sQ0FBQyxHQUFHLEVBQUUsS0FBSyxDQUFDLElBQUksT0FBTyxFQUFFO1FBQ2xDLHdDQUF3QztRQUN4QyxNQUFNLENBQUMsR0FBRyxDQUFDLEdBQUcsS0FBSyxDQUFDO0tBQ3JCO0lBQ0QsT0FBTyxNQUFNLENBQUM7QUFDaEIsQ0FBQztBQU1NLE1BQU0sSUFBSSxHQUFHLEtBQUssV0FBVyxLQUFVLEVBQUUsR0FBUSxFQUFFLFFBQWE7SUFDckUsTUFBTSxFQUFFLE9BQU8sRUFBRSxRQUFRLEVBQUUsR0FBRyxLQUFLLENBQUMsT0FBTyxDQUFDLENBQUMsQ0FBQyxDQUFDLEVBQUUsQ0FBQztJQUNsRCxNQUFNLFdBQVcsR0FBRyxJQUFJLGVBQWUsQ0FBQyxPQUFPLENBQUMsV0FBVyxDQUFvQixDQUFDO0lBQ2hGLE1BQU0sY0FBYyxHQUFHLGNBQWMsQ0FBQyxXQUFXLENBQUMsT0FBTyxFQUFFLENBQWEsQ0FBQztJQUN6RSxNQUFNLEtBQUssR0FBRyxjQUFjLENBQUMsS0FBSyxDQUFDO0lBQ25DLE1BQU0sR0FBRyxHQUFHLE9BQU8sQ0FBQyxHQUFHLENBQUM7SUFDeEIsTUFBTSxXQUFXLEdBQUcsQ0FBQyxHQUFHLEVBQUUsYUFBYSxDQUFDLENBQUM7SUFFekMsUUFBUSxDQUFDLE1BQU0sR0FBRyxLQUFLLENBQUM7SUFDeEIsUUFBUSxDQUFDLGlCQUFpQixHQUFHLElBQUksQ0FBQztJQUVsQyxNQUFNLFFBQVEsR0FBRyxPQUFPLENBQUMsT0FBTyxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUMsQ0FBQyxLQUFLLENBQUM7SUFFL0MsSUFBSSxPQUFPLEdBQUcsTUFBTSxDQUFDLE1BQU0sS0FBSyxDQUFDLFVBQVUsUUFBUSxFQUFFLENBQUMsQ0FBQyxDQUFDLElBQUksRUFBRSxDQUFDO0lBRS9ELElBQUksS0FBSyxJQUFJLFdBQVcsQ0FBQyxPQUFPLENBQUMsR0FBRyxDQUFDLEdBQUcsQ0FBQyxDQUFDLEVBQUU7UUFDMUMsUUFBUSxDQUFDLElBQUksR0FBRyxPQUFPLENBQUMsT0FBTyxDQUM3QixnQkFBZ0IsRUFDaEIsdUhBQXVILEtBQUssbURBQW1ELENBQ2hMLENBQUM7UUFDRixRQUFRLENBQUMsSUFBSSxHQUFHLFFBQVEsQ0FBQyxJQUFJLENBQUMsT0FBTyxDQUNuQyxlQUFlLEVBQ2YsdUZBQXVGLEtBQUssT0FBTyxDQUNwRyxDQUFDO1FBQ0YsUUFBUSxDQUFDLE9BQU8sQ0FBQyxjQUFjLENBQUMsR0FBRztZQUNqQztnQkFDRSxHQUFHLEVBQUUsY0FBYztnQkFDbkIsS0FBSyxFQUFFLDBCQUEwQjthQUNsQztTQUNGLENBQUM7S0FDSDtTQUFNLElBQUksV0FBVyxDQUFDLE9BQU8sQ0FBQyxHQUFHLENBQUMsR0FBRyxDQUFDLENBQUMsRUFBRTtRQUN4QyxRQUFRLENBQUMsSUFBSSxHQUFHLE9BQU8sQ0FBQyxPQUFPLENBQzdCLGdCQUFnQixFQUNoQix1R0FBdUcsQ0FDeEcsQ0FBQztRQUNGLFFBQVEsQ0FBQyxJQUFJLEdBQUcsUUFBUSxDQUFDLElBQUksQ0FBQyxPQUFPLENBQ25DLGVBQWUsRUFDZixnRUFBZ0UsQ0FDakUsQ0FBQztRQUVGLFFBQVEsQ0FBQyxPQUFPLENBQUMsY0FBYyxDQUFDLEdBQUc7WUFDakM7Z0JBQ0UsR0FBRyxFQUFFLGNBQWM7Z0JBQ25CLEtBQUssRUFBRSwwQkFBMEI7YUFDbEM7U0FDRixDQUFDO0tBQ0g7SUFDRCxRQUFRLENBQUMsSUFBSSxFQUFFLFFBQVEsQ0FBQyxDQUFDO0FBQzNCLENBQUMsQ0FBQztBQWhEVyxRQUFBLElBQUksUUFnRGYifQ==